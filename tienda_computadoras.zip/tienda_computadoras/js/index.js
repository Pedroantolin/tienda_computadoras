document.addEventListener("DOMContentLoaded", function () {

    // Catálogo de componentes y marcas

    const componentes = {

        "Tarjeta gráfica": {
            "GeForce RTX 4060": ["ASUS", "MSI", "Gigabyte", "Zotac"],
            "GeForce RTX 4070": ["ASUS", "MSI", "Gigabyte", "Zotac"],
            "GeForce RTX 5060": ["ASUS", "MSI", "Gigabyte", "Zotac"],
            "Radeon RX 7600": ["ASUS", "MSI", "Gigabyte", "Sapphire", "PowerColor"]
        },

        "Procesador": {
            "Ryzen 5 5600": ["AMD"],
            "Ryzen 7 5700X": ["AMD"],
            "Ryzen 5 7600": ["AMD"],
            "Intel Core i5-12400F": ["Intel"],
            "Intel Core i5-14400F": ["Intel"],
            "Intel Core i7-14700K": ["Intel"]
        },

        "Tarjeta madre": {
            "ROG Strix B550-F": ["ASUS"],
            "TUF Gaming B650-Plus": ["ASUS"],
            "MSI B650 Gaming Plus": ["MSI"],
            "B650 AORUS Elite": ["Gigabyte"],
            "B550M Pro4": ["ASRock"]
        },

        "Memoria RAM": {
            "Memoria RAM DDR4 16GB": ["Kingston", "Corsair", "Crucial", "G.Skill"],
            "Memoria RAM DDR5 32GB": ["Kingston", "Corsair", "Crucial", "G.Skill"]
        },

        "Almacenamiento": {
            "SSD NVMe 1TB": ["Samsung", "Kingston", "Western Digital", "Crucial"],
            "SSD NVMe 2TB": ["Samsung", "Kingston", "Western Digital", "Crucial"],
            "Disco duro HDD 2TB": ["Seagate", "Western Digital"]
        },

        "Fuente de poder": {
            "Fuente de poder 650W": ["Corsair", "Cooler Master", "Gigabyte", "MSI"],
            "Fuente de poder 750W": ["Corsair", "Cooler Master", "Gigabyte", "MSI"]
        },

        "Gabinete": {
            "Gabinete ATX": ["Corsair", "Cooler Master", "NZXT", "MSI", "DeepCool"]
        },

        "Refrigeración": {
            "Disipador para procesador": ["Cooler Master", "DeepCool", "Noctua", "Thermalright"],
            "Refrigeración líquida": ["Corsair", "NZXT", "Cooler Master", "DeepCool"]
        },

        "Monitor": {
            "Monitor 24 pulgadas": ["ASUS", "LG", "AOC", "Samsung", "Acer", "MSI"]
        },

        "Teclado": {
            "Teclado mecánico": ["Logitech", "Razer", "Redragon", "Corsair", "HyperX"]
        },

        "Ratón": {
            "Mouse gamer": ["Logitech", "Razer", "Redragon", "Corsair", "Attack Shark"]
        },

        "Periférico": {
            "Audífonos": ["Logitech", "Razer", "HyperX", "Corsair"],
            "Webcam": ["Logitech", "Razer", "ASUS"],
            "Bocinas": ["Logitech", "Creative"]
        },

        "Otro": {
            "Cable o adaptador": ["UGREEN", "Anker", "StarTech"],
            "Accesorio para computadora": ["ASUS", "MSI", "Genérico"]
        }

    };


    // Obtener elementos del formulario

    const categoria = document.getElementById("categoria");
    const nombre = document.getElementById("nombre");
    const marca = document.getElementById("marca");


    // Función para llenar los selectores

    function llenarSelect(select, opciones, mensaje) {

        select.innerHTML = "";

        const inicial = document.createElement("option");

        inicial.value = "";
        inicial.textContent = mensaje;

        select.appendChild(inicial);

        opciones.forEach(opcion => {

            const elemento = document.createElement("option");

            elemento.value = opcion;
            elemento.textContent = opcion;

            select.appendChild(elemento);

        });

        select.disabled = opciones.length === 0;

    }


    // Cuando cambia la categoría

    categoria.addEventListener("change", function () {

        const lista = componentes[categoria.value] || {};

        const opciones = Object.keys(lista);

        llenarSelect(
            nombre,
            opciones,
            "Selecciona un componente"
        );

        llenarSelect(
            marca,
            [],
            "Primero selecciona un componente"
        );

    });


    // Cuando cambia el componente

    nombre.addEventListener("change", function () {

        const lista = componentes[categoria.value] || {};

        const marcas = lista[nombre.value] || [];

        llenarSelect(
            marca,
            marcas,
            "Selecciona una marca"
        );

    });


    // Confirmación antes de eliminar un producto

    const formulariosEliminar = document.querySelectorAll(".formEliminar");

    formulariosEliminar.forEach(formulario => {

        formulario.addEventListener("submit", function (evento) {

            const confirmar = confirm(
                "¿Seguro que deseas eliminar este producto?"
            );

            if (!confirmar) {
                evento.preventDefault();
            }

        });

    });


    // Mensaje de confirmación

    const mensaje = document.getElementById("mensajeSistema");

    if (mensaje) {

        setTimeout(function () {

            mensaje.style.transition = "opacity 0.5s ease";

            mensaje.style.opacity = "0";

            setTimeout(function () {
                mensaje.remove();
            }, 500);

        }, 4000);

    }

});
document.addEventListener("DOMContentLoaded", function () {

    // =====================================
    // 1. ALERTAS AUTOMÁTICAS
    // =====================================

    const alertas = document.querySelectorAll(".alerta");

    alertas.forEach(function (alerta) {

        // La alerta desaparece después de 5 segundos
        setTimeout(function () {
            alerta.classList.add("ocultar");

            // Elimina la alerta después de la animación
            setTimeout(function () {
                alerta.remove();
            }, 450);

        }, 5000);

    });


    // =====================================
    // 2. ANIMACIÓN DE LAS FILAS
    // =====================================

    const filas = document.querySelectorAll("tbody tr");

    filas.forEach(function (fila, indice) {
        fila.style.animationDelay = (indice * 0.05) + "s";
    });


    // =====================================
    // 3. ANIMACIÓN DE LAS TARJETAS
    // =====================================

    const tarjetas = document.querySelectorAll(".tarjeta");

    tarjetas.forEach(function (tarjeta, indice) {
        tarjeta.style.animationDelay = (indice * 0.12) + "s";
    });

});