document.addEventListener("DOMContentLoaded", function () {

    // Catálogo de componentes y sus marcas

    const componentes = {

        "Tarjeta gráfica": {
            "GeForce RTX 4060": ["ASUS", "MSI", "Gigabyte", "Zotac"],
            "GeForce RTX 4070": ["ASUS", "MSI", "Gigabyte", "Zotac"],
            "GeForce RTX 5060": ["ASUS", "MSI", "Gigabyte", "Zotac"],
            "Radeon RX 7600": ["ASUS", "MSI", "Gigabyte", "Sapphire", "PowerColor"]
        },

        "Procesador": {
            "Ryzen 5 5600": ["AMD"],
            "Ryzen 7 5700X": ["AMD"],
            "Ryzen 5 7600": ["AMD"],
            "Intel Core i5-12400F": ["Intel"],
            "Intel Core i5-14400F": ["Intel"],
            "Intel Core i7-14700K": ["Intel"]
        },

        "Tarjeta madre": {
            "ROG Strix B550-F": ["ASUS"],
            "TUF Gaming B650-Plus": ["ASUS"],
            "MSI B650 Gaming Plus": ["MSI"],
            "B650 AORUS Elite": ["Gigabyte"],
            "B550M Pro4": ["ASRock"]
        },

        "Memoria RAM": {
            "Memoria RAM DDR4 16GB": ["Kingston", "Corsair", "Crucial", "G.Skill"],
            "Memoria RAM DDR5 32GB": ["Kingston", "Corsair", "Crucial", "G.Skill"]
        },

        "Almacenamiento": {
            "SSD NVMe 1TB": ["Samsung", "Kingston", "Western Digital", "Crucial"],
            "SSD NVMe 2TB": ["Samsung", "Kingston", "Western Digital", "Crucial"],
            "Disco duro HDD 2TB": ["Seagate", "Western Digital"]
        },

        "Fuente de poder": {
            "Fuente de poder 650W": ["Corsair", "Cooler Master", "Gigabyte", "MSI"],
            "Fuente de poder 750W": ["Corsair", "Cooler Master", "Gigabyte", "MSI"]
        },

        "Gabinete": {
            "Gabinete ATX": ["Corsair", "Cooler Master", "NZXT", "MSI", "DeepCool"]
        },

        "Refrigeración": {
            "Disipador para procesador": ["Cooler Master", "DeepCool", "Noctua", "Thermalright"],
            "Refrigeración líquida": ["Corsair", "NZXT", "Cooler Master", "DeepCool"]
        },

        "Monitor": {
            "Monitor 24 pulgadas": ["ASUS", "LG", "AOC", "Samsung", "Acer", "MSI"]
        },

        "Teclado": {
            "Teclado mecánico": ["Logitech", "Razer", "Redragon", "Corsair", "HyperX"]
        },

        "Ratón": {
            "Mouse gamer": ["Logitech", "Razer", "Redragon", "Corsair", "Attack Shark"]
        },

        "Periférico": {
            "Audífonos": ["Logitech", "Razer", "HyperX", "Corsair"],
            "Webcam": ["Logitech", "Razer", "ASUS"],
            "Bocinas": ["Logitech", "Creative"]
        },

        "Otro": {
            "Cable o adaptador": ["UGREEN", "Anker", "StarTech"],
            "Accesorio para computadora": ["ASUS", "MSI", "Genérico"]
        }

    };


    // Obtener elementos HTML

    const formulario = document.getElementById("formEditar");

    const categoria = document.getElementById("categoria");
    const nombre = document.getElementById("nombre");
    const marca = document.getElementById("marca");

    const campoPrecio = document.getElementById("precio");
    const campoStock = document.getElementById("stock");


    // Recuperar los datos originales desde PHP

    const nombreActual = formulario.dataset.nombreActual;
    const marcaActual = formulario.dataset.marcaActual;


    // Llenar selectores

    function llenarSelect(select, opciones, mensaje, seleccionado = "") {

        select.innerHTML = "";

        const inicial = document.createElement("option");

        inicial.value = "";
        inicial.textContent = mensaje;

        select.appendChild(inicial);

        opciones.forEach(opcion => {

            const elemento = document.createElement("option");

            elemento.value = opcion;
            elemento.textContent = opcion;

            if (opcion === seleccionado) {
                elemento.selected = true;
            }

            select.appendChild(elemento);

        });

        select.disabled = opciones.length === 0;

    }


    // Actualizar componentes según categoría

    function actualizarComponentes(valorSeleccionado = "") {

        const lista = componentes[categoria.value] || {};

        const opciones = Object.keys(lista);

        if (valorSeleccionado && !opciones.includes(valorSeleccionado)) {
            opciones.push(valorSeleccionado);
        }

        llenarSelect(
            nombre,
            opciones,
            "Selecciona un componente",
            valorSeleccionado
        );

    }


    // Actualizar marcas según componente

    function actualizarMarcas(valorSeleccionado = "") {

        const lista = componentes[categoria.value] || {};

        const opciones = [...(lista[nombre.value] || [])];

        if (valorSeleccionado && !opciones.includes(valorSeleccionado)) {
            opciones.push(valorSeleccionado);
        }

        llenarSelect(
            marca,
            opciones,
            "Selecciona una marca",
            valorSeleccionado
        );

    }


    // Eventos de los selectores

    categoria.addEventListener("change", function () {

        actualizarComponentes();

        actualizarMarcas();

        actualizarVistaPrevia();

    });


    nombre.addEventListener("change", function () {

        actualizarMarcas();

        actualizarVistaPrevia();

    });


    marca.addEventListener("change", actualizarVistaPrevia);


    // Cargar los datos originales del producto

    actualizarComponentes(nombreActual);

    actualizarMarcas(marcaActual);


    // Actualizar la vista previa

    function actualizarVistaPrevia() {

        document.getElementById("vistaNombre").textContent =
            nombre.value || "Sin nombre";

        document.getElementById("vistaMarca").textContent =
            marca.value || "Sin marca";

        document.getElementById("vistaCategoria").textContent =
            categoria.value || "Sin categoría";


        // Actualizar precio

        const precio = Number(campoPrecio.value);

        document.getElementById("vistaPrecio").textContent =
            "$" + (
                Number.isFinite(precio) && campoPrecio.value !== ""
                    ? precio.toLocaleString("es-MX", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })
                    : "0.00"
            );


        // Actualizar existencias

        const stock = Math.max(
            0,
            parseInt(campoStock.value, 10) || 0
        );

        document.getElementById("vistaStockNumero").textContent =
            stock + (stock === 1 ? " unidad" : " unidades");


        // Actualizar estado del inventario

        const estado = document.getElementById("vistaEstado");

        const textoEstado = document.getElementById("vistaEstadoTexto");

        estado.classList.remove("bajo", "agotado");


        if (stock === 0) {

            estado.classList.add("agotado");

            textoEstado.textContent = "Agotado";

        } else if (stock <= 5) {

            estado.classList.add("bajo");

            textoEstado.textContent = "Stock bajo";

        } else {

            textoEstado.textContent = "Disponible";

        }

    }


    // Detectar cambios en precio y existencias

    [campoPrecio, campoStock].forEach(campo => {

        campo.addEventListener("input", actualizarVistaPrevia);

        campo.addEventListener("change", actualizarVistaPrevia);

    });


    // Mostrar vista previa inicial

    actualizarVistaPrevia();

});
