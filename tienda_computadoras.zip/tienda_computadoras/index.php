<?php
require_once "conexion.php";

$categoriasValidas = [
    "Tarjeta gráfica",
    "Procesador",
    "Tarjeta madre",
    "Memoria RAM",
    "Almacenamiento",
    "Fuente de poder",
    "Gabinete",
    "Refrigeración",
    "Monitor",
    "Teclado",
    "Ratón",
    "Periférico",
    "Otro"
];

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["registrar"])) {

    $nombre = trim($_POST["nombre"] ?? "");
    $categoria = $_POST["categoria"] ?? "";
    $marca = trim($_POST["marca"] ?? "");
    $precio = $_POST["precio"] ?? "";
    $stock = $_POST["stock"] ?? "";

    if (
        $nombre !== "" &&
        $marca !== "" &&
        in_array($categoria, $categoriasValidas, true) &&
        is_numeric($precio) &&
        is_finite((float)$precio) &&
        (float)$precio >= 0 &&
        filter_var($stock, FILTER_VALIDATE_INT) !== false &&
        (int)$stock >= 0
    ) {

        $precio = (float)$precio;
        $stock = (int)$stock;
        $disponible = $stock > 0 ? 1 : 0;

        $stmt = $conexion->prepare(
            "INSERT INTO productos
            (nombre, categoria, marca, precio, stock, disponible)
            VALUES (?, ?, ?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "sssdii",
            $nombre,
            $categoria,
            $marca,
            $precio,
            $stock,
            $disponible
        );

        if ($stmt->execute()) {

            $stmt->close();

            header("Location: index.php?mensaje=registrado");
            exit;

        }

        $error = "No se pudo registrar el producto.";

        $stmt->close();

    } else {

        $error = "Revisa los datos ingresados. Todos los campos son obligatorios.";

    }
}


$busqueda = trim($_GET["buscar"] ?? "");
$filtro = $_GET["categoria"] ?? "";

$sql = "SELECT id_producto, nombre, categoria, marca, precio, stock, disponible
        FROM productos
        WHERE 1=1";

$parametros = [];
$tipos = "";

if ($busqueda !== "") {

    $sql .= " AND (nombre LIKE ? OR marca LIKE ?)";

    $termino = "%" . $busqueda . "%";

    $parametros[] = $termino;
    $parametros[] = $termino;

    $tipos .= "ss";

}

if (in_array($filtro, $categoriasValidas, true)) {

    $sql .= " AND categoria = ?";

    $parametros[] = $filtro;

    $tipos .= "s";

}

$sql .= " ORDER BY id_producto DESC";

$stmt = $conexion->prepare($sql);

if ($tipos !== "") {
    $stmt->bind_param($tipos, ...$parametros);
}

$stmt->execute();

$stmt->bind_result(
    $id,
    $nombreProducto,
    $categoriaProducto,
    $marcaProducto,
    $precioProducto,
    $stockProducto,
    $disponibleProducto
);

$productos = [];

while ($stmt->fetch()) {

    $productos[] = [
        "id" => $id,
        "nombre" => $nombreProducto,
        "categoria" => $categoriaProducto,
        "marca" => $marcaProducto,
        "precio" => $precioProducto,
        "stock" => $stockProducto,
        "disponible" => $disponibleProducto
    ];

}

$stmt->close();


$resultado = $conexion->query(
    "SELECT
        COUNT(*) AS total,
        COALESCE(SUM(stock), 0) AS unidades,
        COALESCE(SUM(CASE WHEN stock <= 5 THEN 1 ELSE 0 END), 0) AS bajo_stock,
        COALESCE(SUM(CASE WHEN disponible = 1 THEN 1 ELSE 0 END), 0) AS disponibles
     FROM productos"
);

$estadisticas = $resultado->fetch_assoc();


function e($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>TechStore | Inventario</title>

    <link rel="stylesheet" href="css/estilos.css">

</head>

<body>

<div class="contenedor">

    <header class="encabezado">

        <div class="marca">

            <div class="logo">⌘</div>

            <div>

                <h1>TechStore</h1>

                <p class="subtitulo">
                    Administración de componentes e inventario
                </p>

            </div>

        </div>

        <span class="etiqueta">● Sistema de inventario</span>

    </header>


    <?php if (isset($_GET["mensaje"])): ?>

        <div class="alerta" id="mensajeSistema">

            <?php

            if ($_GET["mensaje"] === "registrado") {
                echo "Producto registrado correctamente.";
            } elseif ($_GET["mensaje"] === "actualizado") {
                echo "Producto actualizado correctamente.";
            } elseif ($_GET["mensaje"] === "eliminado") {
                echo "Producto eliminado correctamente.";
            } else {
                echo "Operación completada.";
            }

            ?>

        </div>

    <?php endif; ?>


    <?php if (!empty($error)): ?>

        <div class="alerta error">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <!-- Estadísticas -->

    <section class="estadisticas">

        <div class="tarjeta">

            <small>Tipos de productos</small>

            <div class="numero azul">
                <?= e($estadisticas["total"]) ?>
            </div>

        </div>


        <div class="tarjeta">

            <small>Unidades en inventario</small>

            <div class="numero verde">
                <?= e($estadisticas["unidades"]) ?>
            </div>

        </div>


        <div class="tarjeta">

            <small>Productos con poco stock</small>

            <div class="numero amarillo">
                <?= e($estadisticas["bajo_stock"]) ?>
            </div>

            <small>5 unidades o menos</small>

        </div>


        <div class="tarjeta">

            <small>Productos disponibles</small>

            <div class="numero">
                <?= e($estadisticas["disponibles"]) ?>
            </div>

        </div>

    </section>


    <div class="columnas">

        <!-- Formulario de registro -->

        <section class="panel">

            <h2>＋ Registrar componente</h2>

            <form class="formulario" method="POST" action="index.php">

                <label for="categoria">Categoría</label>

                <select id="categoria" name="categoria" required>

                    <option value="">
                        Selecciona una categoría
                    </option>

                    <?php foreach ($categoriasValidas as $cat): ?>

                        <option value="<?= e($cat) ?>">
                            <?= e($cat) ?>
                        </option>

                    <?php endforeach; ?>

                </select>


                <label for="nombre">Nombre del componente</label>

                <select id="nombre" name="nombre" required disabled>

                    <option value="">
                        Primero selecciona una categoría
                    </option>

                </select>


                <label for="marca">Marca</label>

                <select id="marca" name="marca" required disabled>

                    <option value="">
                        Primero selecciona un componente
                    </option>

                </select>


                <label for="precio">Precio de venta (MXN)</label>

                <input
                    id="precio"
                    type="number"
                    name="precio"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    required
                >


                <label for="stock">Cantidad en inventario</label>

                <input
                    id="stock"
                    type="number"
                    name="stock"
                    min="0"
                    step="1"
                    placeholder="0"
                    required
                >


                <button
                    class="principal"
                    type="submit"
                    name="registrar"
                >
                    Registrar producto
                </button>

            </form>

        </section>


        <!-- Tabla de inventario -->

        <section class="panel">

            <h2>Inventario de componentes</h2>

            <form class="barra-busqueda" method="GET" action="index.php">

                <input
                    type="search"
                    name="buscar"
                    placeholder="Buscar por nombre o marca..."
                    value="<?= e($busqueda) ?>"
                >


                <select name="categoria">

                    <option value="">
                        Todas las categorías
                    </option>

                    <?php foreach ($categoriasValidas as $cat): ?>

                        <option
                            value="<?= e($cat) ?>"
                            <?= $filtro === $cat ? "selected" : "" ?>
                        >
                            <?= e($cat) ?>
                        </option>

                    <?php endforeach; ?>

                </select>


                <button class="principal" type="submit">
                    Buscar
                </button>


                <a class="boton secundario" href="index.php">
                    Limpiar
                </a>

            </form>


            <div class="tabla-contenedor">

                <table>

                    <thead>

                        <tr>
                            <th>Producto</th>
                            <th>Categoría</th>
                            <th>Marca</th>
                            <th>Precio</th>
                            <th>Stock</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>

                    </thead>


                    <tbody>

                    <?php if (count($productos) > 0): ?>

                        <?php foreach ($productos as $p): ?>

                            <tr>

                                <td>
                                    <?= e($p["nombre"]) ?>
                                </td>


                                <td>

                                    <span class="categoria">
                                        <?= e($p["categoria"]) ?>
                                    </span>

                                </td>


                                <td>
                                    <?= e($p["marca"]) ?>
                                </td>


                                <td>
                                    $<?= number_format((float)$p["precio"], 2) ?>
                                </td>


                                <td>

                                    <?php if ($p["stock"] <= 5): ?>

                                        <span class="amarillo">
                                            <?= e($p["stock"]) ?>
                                        </span>

                                    <?php else: ?>

                                        <?= e($p["stock"]) ?>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <?php if ($p["disponible"]): ?>

                                        <span class="estado si">
                                            Disponible
                                        </span>

                                    <?php else: ?>

                                        <span class="estado no">
                                            Agotado
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <div class="acciones">

                                        <a
                                            class="boton secundario"
                                            href="editar.php?id=<?= e($p["id"]) ?>"
                                        >
                                            Editar
                                        </a>


                                        <form
                                            action="eliminar.php"
                                            method="POST"
                                            class="formEliminar"
                                        >

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= e($p["id"]) ?>"
                                            >

                                            <button
                                                class="peligro"
                                                type="submit"
                                            >
                                                Eliminar
                                            </button>

                                        </form>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="7" class="vacio">
                                No se encontraron productos.
                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

    </div>

</div>


<script src="js/index.js"></script>

</body>
</html>
