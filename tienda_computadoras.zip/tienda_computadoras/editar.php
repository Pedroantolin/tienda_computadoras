<?php
require_once "conexion.php";

$categoriasValidas = [
    "Tarjeta gráfica",
    "Procesador",
    "Tarjeta madre",
    "Memoria RAM",
    "Almacenamiento",
    "Fuente de poder",
    "Gabinete",
    "Refrigeración",
    "Monitor",
    "Teclado",
    "Ratón",
    "Periférico",
    "Otro"
];

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    header("Location: index.php");
    exit;
}

$stmt = $conexion->prepare(
    "SELECT nombre, categoria, marca, precio, stock, disponible
     FROM productos
     WHERE id_producto = ?"
);

$stmt->bind_param("i", $id);
$stmt->execute();

$stmt->bind_result(
    $nombreActual,
    $categoriaActual,
    $marcaActual,
    $precioActual,
    $stockActual,
    $disponibleActual
);

if (!$stmt->fetch()) {
    $stmt->close();
    header("Location: index.php");
    exit;
}

$producto = [
    "nombre" => $nombreActual,
    "categoria" => $categoriaActual,
    "marca" => $marcaActual,
    "precio" => $precioActual,
    "stock" => $stockActual,
    "disponible" => $disponibleActual
];

$stmt->close();

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["actualizar"])) {

    $nombre = trim($_POST["nombre"] ?? "");
    $categoria = $_POST["categoria"] ?? "";
    $marca = trim($_POST["marca"] ?? "");
    $precio = $_POST["precio"] ?? "";
    $stock = $_POST["stock"] ?? "";

    $producto = [
        "nombre" => $nombre,
        "categoria" => $categoria,
        "marca" => $marca,
        "precio" => $precio,
        "stock" => $stock,
        "disponible" => is_numeric($stock) && (float)$stock > 0 ? 1 : 0
    ];

    if (
        $nombre === "" ||
        $marca === "" ||
        !in_array($categoria, $categoriasValidas, true) ||
        !is_numeric($precio) ||
        !is_finite((float)$precio) ||
        (float)$precio < 0 ||
        filter_var($stock, FILTER_VALIDATE_INT) === false ||
        (int)$stock < 0
    ) {

        $error = "Verifica los datos. El precio y las existencias deben ser válidos.";

    } else {

        $precio = (float)$precio;
        $stock = (int)$stock;
        $disponible = $stock > 0 ? 1 : 0;

        $stmt = $conexion->prepare(
            "UPDATE productos
             SET nombre = ?,
                 categoria = ?,
                 marca = ?,
                 precio = ?,
                 stock = ?,
                 disponible = ?
             WHERE id_producto = ?"
        );

        $stmt->bind_param(
            "sssdiii",
            $nombre,
            $categoria,
            $marca,
            $precio,
            $stock,
            $disponible,
            $id
        );

        if ($stmt->execute()) {

            $stmt->close();

            header("Location: index.php?mensaje=actualizado");
            exit;

        }

        $error = "No se pudieron guardar los cambios.";

        $stmt->close();
    }
}

function e($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>TechStore | Editar producto</title>

    <link rel="stylesheet" href="css/editar.css">
</head>

<body>

<div class="contenedor">

    <header class="barra-superior">

        <div class="identidad">

            <div class="logo">⌘</div>

            <div>
                <div class="nombre-tienda">
                    Tech<span>Store</span>
                </div>

                <div class="submarca">
                    Administración de inventario
                </div>
            </div>

        </div>

        <a href="index.php" class="volver">
            <span>←</span> Volver al inventario
        </a>

    </header>


    <section class="introduccion">

        <span class="sobretitulo">
            Gestión de productos
        </span>

        <h1>Editar componente</h1>

        <p>
            Actualiza los datos del producto y mantén tu inventario al día.
        </p>

    </section>


    <div class="rejilla">

        <!-- Formulario -->

        <section class="panel">

            <div class="titulo-panel">

                <div class="icono-panel">✎</div>

                <div>
                    <h2>Información del producto</h2>

                    <p class="descripcion-panel">
                        Producto ID #<?= e($id) ?>
                    </p>
                </div>

            </div>


            <?php if ($error !== ""): ?>

                <div class="alerta">
                    ⚠ <?= e($error) ?>
                </div>

            <?php endif; ?>


            <form
                method="POST"
                action="editar.php?id=<?= e($id) ?>"
                id="formEditar"
                data-nombre-actual="<?= e($producto["nombre"]) ?>"
                data-marca-actual="<?= e($producto["marca"]) ?>"
            >

                <div class="grupo">

                    <label for="categoria">
                        Categoría del producto
                    </label>

                    <select id="categoria" name="categoria" required>

                        <option value="">
                            Selecciona una categoría
                        </option>

                        <?php foreach ($categoriasValidas as $cat): ?>

                            <option
                                value="<?= e($cat) ?>"
                                <?= $producto["categoria"] === $cat ? "selected" : "" ?>
                            >
                                <?= e($cat) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="grupo">

                    <label for="nombre">
                        Nombre del componente
                    </label>

                    <select id="nombre" name="nombre" required>

                        <option value="">
                            Selecciona un componente
                        </option>

                    </select>

                    <p class="ayuda">
                        Los componentes disponibles dependen de la categoría elegida.
                    </p>

                </div>


                <div class="grupo">

                    <label for="marca">
                        Marca del fabricante
                    </label>

                    <select id="marca" name="marca" required>

                        <option value="">
                            Selecciona una marca
                        </option>

                    </select>

                </div>


                <div class="separador"></div>


                <div class="dos-columnas">

                    <div class="grupo">

                        <label for="precio">
                            Precio de venta (MXN)
                        </label>

                        <input
                            type="number"
                            id="precio"
                            name="precio"
                            min="0"
                            step="0.01"
                            value="<?= e($producto["precio"]) ?>"
                            required
                        >

                        <p class="ayuda">
                            Precio por unidad.
                        </p>

                    </div>


                    <div class="grupo">

                        <label for="stock">
                            Existencias
                        </label>

                        <input
                            type="number"
                            id="stock"
                            name="stock"
                            min="0"
                            step="1"
                            value="<?= e($producto["stock"]) ?>"
                            required
                        >

                        <p class="ayuda">
                            Cantidad de unidades en inventario.
                        </p>

                    </div>

                </div>


                <div class="botones">

                    <button
                        type="submit"
                        name="actualizar"
                        class="boton guardar"
                    >
                        ✓ Guardar cambios
                    </button>

                    <a href="index.php" class="boton cancelar">
                        Cancelar
                    </a>

                </div>

            </form>

        </section>


        <!-- Vista previa -->

        <aside class="panel resumen">

            <div class="titulo-panel">

                <div class="icono-panel">▣</div>

                <div>
                    <h2>Vista previa</h2>

                    <p class="descripcion-panel">
                        Resumen del componente
                    </p>
                </div>

            </div>


            <div class="producto-destacado">

                <div class="producto-icono">▤</div>

                <div class="producto-etiqueta">
                    Producto en edición
                </div>

                <h3 class="producto-nombre" id="vistaNombre">
                    <?= e($producto["nombre"]) ?>
                </h3>

                <div class="producto-marca" id="vistaMarca">
                    <?= e($producto["marca"]) ?>
                </div>

                <div class="precio-etiqueta">
                    Precio de venta
                </div>

                <div class="precio-grande" id="vistaPrecio">
                    $<?= number_format((float)$producto["precio"], 2) ?>
                </div>

            </div>


            <div class="lista-resumen">

                <div class="fila-resumen">

                    <span>Categoría</span>

                    <strong id="vistaCategoria">
                        <?= e($producto["categoria"]) ?>
                    </strong>

                </div>


                <div class="fila-resumen">

                    <span>Existencias</span>

                    <strong id="vistaStockNumero">
                        <?= e($producto["stock"]) ?> unidades
                    </strong>

                </div>


                <div class="fila-resumen">

                    <span>Estado del inventario</span>

                    <strong>

                        <span
                            class="stock-indicador <?= (int)$producto["stock"] === 0 ? "agotado" : ((int)$producto["stock"] <= 5 ? "bajo" : "") ?>"
                            id="vistaEstado"
                        >

                            <span class="punto"></span>

                            <span id="vistaEstadoTexto">

                                <?php
                                if ((int)$producto["stock"] === 0) {
                                    echo "Agotado";
                                } elseif ((int)$producto["stock"] <= 5) {
                                    echo "Stock bajo";
                                } else {
                                    echo "Disponible";
                                }
                                ?>

                            </span>

                        </span>

                    </strong>

                </div>

            </div>


            <div class="nota-seguridad">

                <strong>ⓘ Información importante</strong>

                Los cambios se guardarán en la base de datos cuando pulses
                <b>Guardar cambios</b>. Si cancelas, regresarás al inventario
                sin aplicar las modificaciones.

            </div>

        </aside>

    </div>


    <footer class="pie">
        TechStore · Administración de componentes
    </footer>

</div>

<script src="js/editar.js"></script>

</body>
</html>
